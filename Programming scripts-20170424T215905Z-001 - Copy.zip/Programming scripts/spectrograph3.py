import serial
import time
from Tkinter import *
from ttk import *
import os
from pprint import pprint

leading_dummy_pixels = 16
leading_dark_pixels = 13
signal_pixels = 3648
trailing_dark_pixels = 4
trailing_dummy_pixels = 10
skip_pixels = leading_dark_pixels + leading_dummy_pixels
total_pixels = leading_dummy_pixels + leading_dark_pixels + signal_pixels + trailing_dark_pixels + trailing_dummy_pixels
text_color = "#000000"
cursor_color = "#aa0000"

class Application(Frame):

    def __init__(self, master=None, port=None, exposure=10):
        Frame.__init__(self, master)
        self.parent = master
        self.pack()
        self.result = {}
        self.entry_text = ''
        self.dark = [0] * total_pixels
        self.flat = [1] * total_pixels
        value = 0
        if os.path.isfile("flat.csv"):
            with open("flat.csv", "r") as fp:
                for line in fp:
                    parts = line.split(",")
                    self.flat[int(parts[0])] = float(parts[1])


        self.exposure = StringVar()
        self.exposure.set(str(exposure))
        self.canvas = None
        self.port = port
        self.ser = serial.Serial(self.port, 115200, timeout=1)
        self.TOP = None
        self.RUN = None
        self.CLEAR = None
        self.QUIT = None
        self.EXPOSURE = None
        self.SETEXP = None
        self.DARK = None
        self.createWidgets()


    def createWidgets(self):

        # self.menubar = Menu(self.parent)
        # fileMenu = Menu(self.menubar)
        # fileMenu.add_command(label="Exit", command=self.onExit)
        # self.menubar.add_cascade(label="File", menu=fileMenu)
        # fileMenu.add_command(label="Dark", command=self.make_dark)
        # fileMenu.add_command(label="Flat", command=self.make_flat)

        # try:
        #     self.parent.config(menu=self.menubar)
        # except AttributeError:
        #     # master is a toplevel window (Python 1.4/Tkinter 1.63)
        #     self.parent.tk.call(self.parent, "config", "-menu", self.menubar)

        self.RUN = Button(self)
        self.RUN["text"] = "Sample"
        self.RUN["command"] = self.run
        self.RUN.grid(row=0, column=0)

        self.CLEAR = Button(self)
        self.CLEAR["text"] = "Clear"
        self.CLEAR["command"] = self.clear
        self.CLEAR.grid(row=0, column=1)

        self.QUIT = Button(self)
        self.QUIT["text"] = "Quit"
        self.QUIT["command"] = self.quit
        self.QUIT.grid(row=0, column=2)

        self.EXPOSURE = Entry(self, textvariable=self.exposure)
        self.EXPOSURE.grid(row=0, column=8)

        self.SETEXP = Button(self)
        self.SETEXP["text"] = "Exposure"
        self.SETEXP["command"] = self.send_exposure
        self.SETEXP.grid(row=0, column=9)

        self.DARK = Button(self)
        self.DARK["text"] = "Dark"
        self.DARK["command"] = self.make_dark
        self.DARK.grid(row=0, column=10)

        self.FLAT = Button(self)
        self.FLAT["text"] = "Flat"
        self.FLAT["command"] = self.make_flat
        self.FLAT.grid(row=0, column=11)

        self.canvas1 = Canvas(self, bg="white", height=256, width=int(signal_pixels/3))
        self.canvas1.config(scrollregion=self.canvas1.bbox(ALL), borderwidth=0, relief=GROOVE, highlightthickness=0)
        self.canvas1.bind("<Button-1>", self.mouse_click)
        self.canvas1.grid(row=1, columnspan=12, pady=(0, 25), padx=(20, 20))

        self.canvas2 = Canvas(self, bg="white", height=258, width=int(signal_pixels/3))
        self.canvas2.config(scrollregion=self.canvas1.bbox(ALL), borderwidth=0, relief=GROOVE, highlightthickness=0)
        self.canvas2.bind("<Button-1>", self.mouse_click)
        self.canvas2.grid(row=2, columnspan=12, pady=(0, 25), padx=(20, 20))

        self.canvas3 = Canvas(self, bg="white", height=258, width=int(signal_pixels/3))
        self.canvas3.config(scrollregion=self.canvas1.bbox(ALL), borderwidth=0, relief=GROOVE, highlightthickness=0)
        self.canvas3.bind("<Button-1>", self.mouse_click)
        self.canvas3.grid(row=3, columnspan=12, pady=(0, 25), padx=(20, 20))

        self.blank_graph()

        self.popup = Menu(root, tearoff=0)
        self.popup.add_command(label="Start Zoom", command=self.zoom_start)  # , command=next) etc...
        self.popup.add_command(label="End Zoom", command=self.zoom_end)
        self.popup.add_separator()
        self.popup.add_command(label="Home")
        self.canvas1.bind("<Button-2>", self.do_popup)
        self.canvas2.bind("<Button-2>", self.do_popup)
        self.canvas3.bind("<Button-2>", self.do_popup)
        self.canvas1.bind("<B1-Motion>", self.do_drag)
        self.canvas2.bind("<B1-Motion>", self.do_drag)
        self.canvas3.bind("<B1-Motion>", self.do_drag)
        self.canvas1.bind("<ButtonRelease-1>", self.end_drag)
        self.canvas2.bind("<ButtonRelease-1>", self.end_drag)
        self.canvas3.bind("<ButtonRelease-1>", self.end_drag)



        self.zoom_item = None
        self.zoom_owner = None
        self.drag_item = None
        self.drag_owner = None
        self.drag_start_x = 0
        self.drag_start_pixel = 0
        self.drag_end_pixel = 0
        self.zoom_items = None

    def end_drag(self, event):
        print self.drag_start_pixel, self.drag_end_pixel
        if self.drag_item:
            items = {}
            for x in range(self.drag_start_pixel, self.drag_end_pixel):

                tag = "p" + str(x)
                item = self.drag_owner.find_withtag(tag)
                try:
                    value_tag = self.drag_owner.gettags(item)[2]
                    items[x] = int(value_tag[1:])
                except Exception as e:
                    print e.message
            self.zoom_items = items
            print items
            self.show_zoom()

    def do_drag(self, event):

        tags = list(event.widget.gettags(event.widget.find_closest(event.x, event.y, halo=25)))
        try:
            pixel = int(tags[1][1:]) - skip_pixels - 5
            value = int(tags[2][1:])
            print pixel
            if not self.drag_item:
                self.drag_start_pixel = pixel + 16
                self.drag_item = event.widget.find_closest(event.x, event.y, halo=25)
                self.drag_owner = event.widget
                self.drag_start_x = event.x
                self.drag_rect = self.drag_owner.create_rectangle(self.drag_start_x, 1, self.drag_start_x + 1,
                                                                  255, fill="#00ffff", tags="drag_rect")
            else:
                self.drag_owner.coords("drag_rect", self.drag_start_x, 1, event.x, 255)
                self.drag_owner.tag_lower(self.drag_rect)
                self.drag_end_pixel = pixel + 16
        except:
            pass

    def show_zoom(self):

        top = Toplevel()
        top.title("Zoom")
        top.canvas = Canvas(top, bg="white", height=512, width=1024)
        top.canvas.grid()
        top.QUIT = Button(self)
        top.QUIT["text"] = "Quit"
        top.QUIT["command"] = self.quit
        top.QUIT.grid(row=0, column=2)

        pixels = self.drag_end_pixel - self.drag_start_pixel
        min_value = 65536
        max_value = 0
        for x in range(self.drag_start_pixel, self.drag_end_pixel):
            if x not in self.zoom_items:
                continue
            y = self.zoom_items[x]
            if y > max_value:
                max_value = y
            elif y < min_value:
                min_value = y

        y_factor = float(max_value - min_value) / 512
        x_factor = float(self.drag_end_pixel - self.drag_start_pixel) / 1024

        for x in range(min_value, max_value, 100):
            top.canvas.create_line(0, 511 - (x-min_value), 1023, 511 - (x-min_value), fill="#eeeeee", width=1)
            top.canvas.create_text(25, 511-(x-min_value), state=NORMAL, text=str(x))

        for x in range(self.drag_start_pixel, self.drag_end_pixel, 25):
            x1 = x - self.drag_start_pixel
            top.canvas.create_line(x1/x_factor, 0, x1/x_factor, 511, fill="#eeeeee", width=1)
            top.canvas.create_text(x1/x_factor, 500, state=NORMAL, text=str(x))

        for x in range(self.drag_start_pixel, self.drag_end_pixel):
            x1 = int((x - self.drag_start_pixel) / x_factor)
            y1 = int((self.zoom_items[x] - min_value) / y_factor)
            if y1 < 0:
                y1 = 0

            try:
                x2 = int(((x + 1) - self.drag_start_pixel) / x_factor)
                y2 = int((self.zoom_items[x+1] - min_value) / y_factor)
                if y2 < 0:
                    y2 = 0
            except:
                break
            top.canvas.create_line(x1, 511 - y1, x2, 511 - y2, fill="#0070A0", width=1, tags=("line","p" + str(x), "v" + str(self.zoom_items[x])))
        top.mainloop()
        top.quit()

    def zoom_start(self):

        tags = list(self.zoom_owner.gettags(self.zoom_item))
        print tags
        self.zoom_start_pixel = int(tags[1][1:]) - skip_pixels - 5
        print "zoom_start %s" % self.zoom_start_pixel

    def zoom_end(self):

        tags = list(self.zoom_owner.gettags(self.zoom_item))
        print tags
        self.zoom_end_pixel = pixel = int(tags[1][1:]) - skip_pixels - 5
        print "zoom_end %s" % self.zoom_end_pixel

    def do_popup(self, event):
        try:
            self.zoom_item = event.widget.find_closest(event.x, event.y, halo=5)
            self.zoom_owner = event.widget
            self.popup.tk_popup(event.x_root, event.y_root, 0)
        except TclError as e:
            print e.message
        finally:
            # make sure to release the grab (Tk 8.0a1 only)
            self.popup.grab_release()

    def mouse_click(self, event):

        if self.drag_item:
            self.drag_start_pixel = 0
            self.drag_owner.delete("drag_rect")
            self.drag_owner = None
            self.drag_item = None

        item = event.widget.find_closest(event.x, event.y, halo=5)
        tags = list(event.widget.gettags(item))
        self.clear_cursors()
        try:
            pos_x = event.x
            pixel = int(tags[1][1:]) - skip_pixels - 5
            value = int(tags[2][1:])

            event.widget.create_line(pos_x, 0, pos_x, 255, fill=cursor_color, width=2, tags="cursor")
            if event.x < 600:
                event.widget.create_text(pos_x + 10, 128, anchor=NW, fill=text_color, state=NORMAL, text=str(pixel) + " = " + str(value), tags="cursor")
            else:
                event.widget.create_text(pos_x - 10, 128, anchor=NE, fill=text_color, state=NORMAL, text=str(pixel) + " = " + str(value), tags="cursor")
        except:
            pass


    def make_dark(self):

        for z in range(0, 5):
            self.ser.write("r\n")

            chars = ''
            while True:
                char = self.ser.read()
                if char == '':
                    break
                chars += char

            data = chars.split("\n")

            for x in data:
                x = x.strip()
                if x == '':
                    continue
                y = x.split(",")

                if len(y) < 2:
                    continue
                if y[0] == '' or y[1] == '':
                    continue
                try:
                    a = int(y[0])
                    b = int(y[1])
                except:
                    continue

                if b > 0:
                    self.dark[a] += b
        for a in range(0, total_pixels):
            self.dark[a] /= 5

        filename = "dark." + ("000" + self.exposure.get())[-3:] + ".csv"
        fp = open(filename, "w")
        for a in range(0, total_pixels):
            fp.write(str(a) + "," + str(self.dark[a]) + "\n")
        fp.close()

        self.send_exposure()

    def make_flat(self):

        flat = [0] * total_pixels
        for z in range(0, 5):
            self.ser.write("r\n")

            chars = ''
            while True:
                char = self.ser.read()
                if char == '':
                    break
                chars += char

            data = chars.split("\n")

            for x in data:
                x = x.strip()
                if x == '':
                    continue
                y = x.split(",")

                if len(y) < 2:
                    continue
                if y[0] == '' or y[1] == '':
                    continue
                try:
                    a = int(y[0])
                    b = int(y[1])
                except:
                    continue

                if b > 0:
                    flat[a] += b

        path = ("000" + self.exposure.get())[-3:]
        print "dark." + path + ".csv"
        self.dark = [0] * total_pixels
        if os.path.isfile("dark." + path + ".csv"):
            with open("dark." + path + ".csv", "r") as fd:
                for line in fd:
                    parts = line.split(",")
                    self.dark[int(parts[0])] = int(parts[1])
            print "Dark loaded"

        for a in range(0, total_pixels):
            print flat[a], self.dark[a]
            flat[a] = flat[a]/5 - self.dark[a]

        value = 0
        for a in range(0, total_pixels):
            if flat[a] > value:
                value = flat[a]

        for a in range(0, total_pixels):
            flat[a] = float(float(flat[a]) / float(value))

        filename = "flat.csv"
        fp = open(filename, "w")

        for a in range(0, total_pixels):
            fp.write(str(a) + "," + str(flat[a]) + "\n")
        fp.close()

        self.send_exposure()

    def write_serial(self, string):

        for c in string:
            self.ser.write(c)


    def send_exposure(self):

        exp = self.exposure.get()
        try:
            exposure = int(exp)
        except Exception as e:
            print e.message
            exposure = 10

        if exposure > 1000:
            exposure = 1000
            self.exposure.set("1000")

        exp = "e" + ("000" + str(exposure))[-3:]
        while True:
            self.write_serial(exp)
            self.write_serial("\n")
            data = self.ser.read(10)
            print data
            if data == exp:
                break

    def run(self):

        buckets = [0] * 3694
        counts = [0] * 3694
        self.result = {}

        self.ser.read()
        self.ser.read()

        time.sleep(0.1)
        self.ser.write("r\n")
        chars = ''
        while True:
            char = self.ser.read()
            if char == '':
                break
            chars += char
            # sys.stdout.write(char)
        data = chars.split("\n")

        for x in data:
            x = x.strip()
            if x == '':
                continue
            y = x.split(",")

            if len(y) < 2:
                continue
            if y[0] == '' or y[1] == '':
                continue
            print y[0], format(int(y[1]), '04X')
            a = int(y[0])
            b = int(y[1]) & 0xFFFFFFFF

            if b > 0:
                counts[a] += 1
                buckets[a] += b

        output = []
        for x in range(0, total_pixels):
            val = buckets[x]
            output.append(val)

        fp = open("ccd.csv", "w")
        for x in range(0, total_pixels):
            y = x
            value = int(output[x])
            if self.flat[y] > 0:
                value = int(float(value) / float(self.flat[y]))
            self.result[y] = int(value)

            # fp.write(str(x) + "," + str(output[x]) + "\n")
            fp.write(str(x) + "," + str(self.result[y]) + "\n")
        fp.close()
        self.draw_graph()

    def clear_cursors(self):
        self.canvas1.delete("cursor")
        self.canvas2.delete("cursor")
        self.canvas3.delete("cursor")

    def clear(self):
        self.canvas1.delete("line")
        self.canvas2.delete("line")
        self.canvas3.delete("line")
        try:
            self.drag_owner.delete("drag_rect")
        except:
            pass
        self.clear_cursors()
        self.blank_graph()

    def blank_graph(self):

        for x in range(0, 1215, 25):
            self.canvas1.create_line(x, 0, x, 255, fill="#eeeeee", width=1)
            self.canvas2.create_line(x, 0, x, 255, fill="#eeeeee", width=1)
            self.canvas3.create_line(x, 0, x, 255, fill="#eeeeee", width=1)
        for x in range(0, 1215, 100):
            self.canvas1.create_line(x, 0, x, 255, fill="#bbbbbb", width=1)
            self.canvas2.create_line(x, 0, x, 255, fill="#bbbbbb", width=1)
            self.canvas3.create_line(x, 0, x, 255, fill="#bbbbbb", width=1)
        for y in range(0, 100, 10):
            if y > 0:
                z = 255 - (2.5 * y)
            else:
                z = 255
            self.canvas1.create_line(0, z, 1232, z, fill="#eeeeee", width=1)
            self.canvas2.create_line(0, z, 1232, z, fill="#eeeeee", width=1)
            self.canvas3.create_line(0, z, 1232, z, fill="#eeeeee", width=1)

        z = 255 - 100
        self.canvas1.create_line(0, z, 1232, z, fill="#bbbbbb", width=1)
        self.canvas2.create_line(0, z, 1232, z, fill="#bbbbbb", width=1)
        self.canvas3.create_line(0, z, 1232, z, fill="#bbbbbb", width=1)

        z = 255 - 200
        self.canvas1.create_line(0, z, 1232, z, fill="#bbbbbb", width=1)
        self.canvas2.create_line(0, z, 1232, z, fill="#bbbbbb", width=1)
        self.canvas3.create_line(0, z, 1232, z, fill="#bbbbbb", width=1)

        x_min = 0
        x_max = int(signal_pixels/3) + x_min - 1
        y_min = 0
        y_max = 255
        self.canvas1.create_line(x_min, y_min, x_min, y_max, fill="#555555", width=1)
        self.canvas1.create_line(x_min, y_max, x_max, y_max, fill="#555555", width=1)
        self.canvas1.create_line(x_max, y_max, x_max, y_min, fill="#555555", width=1)
        self.canvas1.create_line(x_max, y_min, x_min, y_min, fill="#555555", width=1)
        self.canvas2.create_line(x_min, y_min, x_min, y_max, fill="#555555", width=1)
        self.canvas2.create_line(x_min, y_max, x_max, y_max, fill="#555555", width=1)
        self.canvas2.create_line(x_max, y_max, x_max, y_min, fill="#555555", width=1)
        self.canvas2.create_line(x_max, y_min, x_min, y_min, fill="#555555", width=1)
        self.canvas3.create_line(x_min, y_min, x_min, y_max, fill="#555555", width=1)
        self.canvas3.create_line(x_min, y_max, x_max, y_max, fill="#555555", width=1)
        self.canvas3.create_line(x_max, y_max, x_max, y_min, fill="#555555", width=1)
        self.canvas3.create_line(x_max, y_min, x_min, y_min, fill="#555555", width=1)

    def draw_graph(self):

        third_1 = skip_pixels + (signal_pixels/3)
        third_2 = third_1 + (signal_pixels/3)

        for x in range(skip_pixels, total_pixels):
            if x not in self.result:
                continue
            if x > (leading_dark_pixels + leading_dummy_pixels + signal_pixels):
                break
            if x < third_1:
                x1 = x
                y1 = 255 - (self.result[x1]/256)
                if y1 < 0:
                    y1 = 0
                x2 = x1+1
                y2 = 255 - (self.result[x2]/256)
                if y2 < 0:
                    y2 = 0
                self.canvas1.create_line((x1-skip_pixels), y1, (x2-skip_pixels), y2, fill="#0070A0", width=1, tags=("line","p" + str(x1), "v" + str(self.result[x1])))
            elif x < third_2:
                x1 = x
                y1 = 255 - (self.result[x1] / 256)
                if y1 < 0:
                    y1 = 0
                x2 = x1 + 1
                y2 = 255 - (self.result[x2] / 256)
                if y2 < 0:
                    y2 = 0
                self.canvas2.create_line((x1 - third_1), y1, (x2 - third_1), y2, fill="#0070A0", width=1, tags=("line","p" + str(x1), "v" + str(self.result[x1])))
            else:
                x1 = x
                y1 = 255 - (self.result[x1] / 256)
                if y1 < 0:
                    y1 = 0
                x2 = x1 + 1
                y2 = 255 - (self.result[x2] / 256)
                if y2 < 0:
                    y2 = 0
                self.canvas3.create_line((x1 - third_2), y1, (x2 - third_2), y2, fill="#0070A0", width=1, tags=("line","p" + str(x1), "v" + str(self.result[x1])))

    def onExit(self):
        self.quit()


root = Tk()
app = Application(master=root, port="COM5", exposure=10)
app.master.title("TCD1304 Sampler")
app.mainloop()
app.ser.close()
root.destroy()
